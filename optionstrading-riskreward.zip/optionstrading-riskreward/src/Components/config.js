// config.js
const API_BASE_URL = 'https://crud-2-6ptv.onrender.com/api';

export default API_BASE_URL;
