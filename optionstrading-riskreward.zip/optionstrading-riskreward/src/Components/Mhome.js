import React from 'react'

function Mhome() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
    <p className="font-serif text-2xl text-gray-800">
      Force your mind to think
    </p>
    <p>Strategy: Wait for Movement , Wait You have full day,Take 1 trade and wait for next movement,you get 300 to 500 wait for best next setup.</p>
  </div>
  )
}

export default Mhome